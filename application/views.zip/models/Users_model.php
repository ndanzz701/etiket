<?php
	class Users_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function login($username, $password){
			$query = $this->db->get_where('login', array('username'=>$username, 'password'=>md5($password)));
			return $query->row_array();
		}

	}
?>